@echo off
setlocal
cd /d "%~dp0"
title Build Sodium Addon

echo ========================================
echo        SODIUM ADDON - MOD BUILDER
echo ========================================
echo.

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java is not installed.
  echo Install Java 21, then double-click this file again.
  echo Download: https://adoptium.net/temurin/releases/?version=21
  pause
  exit /b 1
)

echo Checking Java installation...
java -version
if errorlevel 1 (
  echo ERROR: Java could not start. Install Java 21.
  pause
  exit /b 1
)

echo.
set "GRADLE_VERSION=8.14.3"
set "GRADLE_ROOT=%LOCALAPPDATA%\SodiumAddonGradle"
set "GRADLE_HOME=%GRADLE_ROOT%\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME%\bin\gradle.bat"

if not exist "%GRADLE_EXE%" (
  echo Downloading Gradle %GRADLE_VERSION%... This may take a few minutes.
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $root=Join-Path $env:LOCALAPPDATA 'SodiumAddonGradle'; New-Item -ItemType Directory -Force -Path $root | Out-Null; $zip=Join-Path $root 'gradle.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath $root -Force; Remove-Item $zip -Force"
  if errorlevel 1 (
    echo.
    echo ERROR: Gradle could not be downloaded. Check your internet connection.
    pause
    exit /b 1
  )
)

echo.
echo Building the mod. The first build downloads Minecraft and Fabric files.
echo Please wait...
call "%GRADLE_EXE%" --no-daemon build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Take a screenshot of this window and send it to ChatGPT.
  pause
  exit /b 1
)

if not exist "build\libs\sodium-addon-1.0.0.jar" (
  echo.
  echo ERROR: The expected mod JAR was not found in build\libs.
  pause
  exit /b 1
)

copy /y "build\libs\sodium-addon-1.0.0.jar" "Sodium-Addon.jar" >nul
echo.
echo ========================================
echo BUILD SUCCESSFUL!
echo Your mod is: Sodium-Addon.jar
echo Copy it into your Minecraft mods folder.
echo ========================================
pause
