# Sodium Addon (AutoTotem feature)

A client-side Fabric source project targeting Minecraft Java 1.21.11.

## Function
When the local player receives the vanilla totem-pop entity event, the mod checks the hotbar and selects the first slot containing a Totem of Undying. It does not move items or refill the offhand.

## Configuration
Open **Mods → Sodium Addon → Configure** in Mod Menu to turn Auto Switch ON or OFF. The setting is saved in `config/sodium-addon.json`.

## Build
Requirements: Java 21 and a compatible Gradle installation.

```bash
gradle build
```

The compiled JAR should appear in `build/libs/`.

## Install
1. Install Fabric Loader for Minecraft 1.21.11.
2. Install Fabric API and Mod Menu versions compatible with Minecraft 1.21.11.
3. Put the compiled JAR from `build/libs/` into your `.minecraft/mods` folder.
4. Launch the Fabric 1.21.11 profile.

## Important
- This ZIP contains source code, not a precompiled JAR.
- The project has not been compiled or tested in this environment; verify it against the exact 1.21.11 Fabric mappings before use.
- The mod makes ordinary client slot-selection changes. It does not disguise automation or bypass server anti-cheat; server rules may prohibit automated switching.
