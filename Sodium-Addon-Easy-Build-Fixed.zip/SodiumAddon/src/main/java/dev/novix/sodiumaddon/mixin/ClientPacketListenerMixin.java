package dev.novix.sodiumaddon.mixin;

import dev.novix.sodiumaddon.AutoTotemConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.multiplayer.ClientPacketListener;

@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {
    // Entity event 35 is the vanilla totem-of-undying activation animation.
    @Inject(method = "handleEntityEvent", at = @At("HEAD"))
    private void sodiumAddon$onEntityEvent(ClientboundEntityEventPacket packet, CallbackInfo ci) {
        if (!AutoTotemConfig.enabled) return;

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) return;
        if (packet.getEventId() != 35) return;
        if (packet.getEntity(minecraft.level) != minecraft.player) return;

        Inventory inventory = minecraft.player.getInventory();

        // If the currently selected main-hand item is already a totem, the pop
        // was probably from the main hand; don't switch away from that slot.
        if (inventory.getSelectedItem().is(Items.TOTEM_OF_UNDYING)) return;

        // Search the hotbar in slot order and select the first available totem.
        for (int slot = 0; slot < 9; slot++) {
            if (inventory.getItem(slot).is(Items.TOTEM_OF_UNDYING)) {
                inventory.setSelectedSlot(slot);
                return;
            }
        }
    }
}
