package dev.novix.sodiumaddon;

import net.fabricmc.api.ClientModInitializer;

public final class SodiumAddonClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AutoTotemConfig.load();
    }
}
