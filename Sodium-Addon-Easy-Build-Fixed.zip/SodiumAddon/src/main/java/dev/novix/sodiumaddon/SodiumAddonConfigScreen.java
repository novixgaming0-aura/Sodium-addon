package dev.novix.sodiumaddon;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class SodiumAddonConfigScreen extends Screen {
    private final Screen parent;
    private Button toggleButton;

    public SodiumAddonConfigScreen(Screen parent) {
        super(Component.literal("Sodium Addon"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        toggleButton = Button.builder(toggleLabel(), button -> {
            AutoTotemConfig.enabled = !AutoTotemConfig.enabled;
            AutoTotemConfig.save();
            button.setMessage(toggleLabel());
        }).bounds(centerX - 100, centerY - 10, 200, 20).build();
        addRenderableWidget(toggleButton);

        addRenderableWidget(Button.builder(Component.literal("Done"), button -> {
            AutoTotemConfig.save();
            this.minecraft.setScreen(parent);
        }).bounds(centerX - 100, centerY + 20, 200, 20).build());
    }

    private Component toggleLabel() {
        return Component.literal("Auto Switch: " + (AutoTotemConfig.enabled ? "ON" : "OFF"));
    }

    @Override
    public void onClose() {
        AutoTotemConfig.save();
        this.minecraft.setScreen(parent);
    }
}
