package dev.novix.sodiumaddon;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class AutoTotemConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("sodium-addon.json");

    public static boolean enabled = true;

    private AutoTotemConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        try {
            JsonObject json = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            if (json != null && json.has("enabled")) {
                enabled = json.get("enabled").getAsBoolean();
            }
        } catch (Exception ignored) {
            enabled = true;
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            JsonObject json = new JsonObject();
            json.addProperty("enabled", enabled);
            Files.writeString(FILE, GSON.toJson(json));
        } catch (IOException exception) {
            System.err.println("[Sodium Addon] Could not save config: " + exception.getMessage());
        }
    }
}
