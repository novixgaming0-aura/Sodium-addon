SODIUM ADDON - EASY BUILD GUIDE

1. Install Java 21 (if you do not already have it):
   https://adoptium.net/temurin/releases/?version=21
   Choose Windows x64, JDK, then install it.

2. Make sure you have Minecraft Java Edition 1.21.11 with Fabric Loader installed.

3. Double-click BUILD-MOD.bat in this folder.
   Do not type anything in Command Prompt. The file does the build for you.
   The first run needs internet and may take several minutes to download files.

4. If it says BUILD SUCCESSFUL, you will see Sodium-Addon.jar in this folder.

5. Press Windows key + R, type %appdata%\.minecraft\mods and press Enter.
   If the mods folder does not exist, create a folder named mods.

6. Copy Sodium-Addon.jar into that mods folder.

7. Start the Fabric 1.21.11 profile. Mod Menu is optional but recommended for the settings toggle.

If the build fails, take a screenshot of the open window and ask for help. Do not rename the JAR.

Note: This is a source project with an automated build helper, not a precompiled/tested JAR.
